package com.example.projectastronomyapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    EditText  pass;
    EditText email;
    ProgressDialog progressDialog;
    Button showPassbtn,login_user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login_user = (Button) findViewById(R.id.loginUser);
        Button back=(Button) findViewById(R.id.back);

        TextView resetPass = (TextView) findViewById(R.id.resetPassword);
        email=(EditText) findViewById(R.id.etEmail);
        pass = (EditText) findViewById(R.id.etPassword);
        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog=new ProgressDialog(Login.this);

        showPassbtn=(Button) findViewById(R.id.showpassbtn);
        showPassbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(pass.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    Drawable img = showPassbtn.getContext().getResources().getDrawable(R.drawable.baseline_disabled_visible_24);
                    showPassbtn.setCompoundDrawablesWithIntrinsicBounds( img, null, null, null);
                    //Show Password
                    pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{

                    Drawable img = showPassbtn.getContext().getResources().getDrawable(R.drawable.baseline_remove_red_eye_24);
                    showPassbtn.setCompoundDrawablesWithIntrinsicBounds( img, null, null, null);
                    //Hide Password
                    pass.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }

                }
        });

        login_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String emailV=email.getText().toString().trim();
                String passwordV=pass.getText().toString().trim();

                if(emailV.isEmpty()||passwordV.isEmpty()){
                    Dialog dialog=new Dialog(Login.this);
                    dialog.setContentView(R.layout.dialog_layout);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                    Button close= dialog.findViewById(R.id.cancelbtn);
                    TextView head= dialog.findViewById(R.id.errorMsg);
                    TextView msg=dialog.findViewById(R.id.detail);
                    head.setText("Error Cardinalities !");
                    msg.setText("Make Sure to Fill Compelety. Don't Miss any field.");

                    close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.cancel();
                        }
                    });
                    dialog.show();
                    return  ;
                }


                progressDialog.show();

                firebaseAuth.signInWithEmailAndPassword(emailV,passwordV)
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                Toast.makeText(Login.this, "Login SuccessFul", Toast.LENGTH_SHORT).show();

                                Intent splashIntent = new Intent(Login.this, SplashScreen.class);
                                splashIntent.putExtra("redirectToHome", true); // Pass an extra flag to indicate redirecting to the home screen
                                startActivity(splashIntent);
                                finish();
                                //
//                                Intent loginIntent = new Intent(Login.this,Home.class);
//                                loginIntent.putExtra("email",emailV);
//                                startActivity(loginIntent);
//                                finish();
                            progressDialog.cancel();

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Dialog dialog=new Dialog(Login.this);
                                dialog.setContentView(R.layout.dialog_layout);
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                                dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                                Button close= dialog.findViewById(R.id.cancelbtn);
                                TextView head= dialog.findViewById(R.id.errorMsg);
                                TextView msg=dialog.findViewById(R.id.detail);
                                head.setText("Error FireBase !");
                                msg.setText(e.getMessage());
                                close.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog.cancel();
                                    }
                                });
                                dialog.show();
                            progressDialog.cancel();
                            }
                        });



            }
        });


        resetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show();
                firebaseAuth.sendPasswordResetEmail(email.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(Login.this, "Check Email", Toast.LENGTH_SHORT).show();
                                progressDialog.cancel();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(Login.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                progressDialog.cancel();
                            }
                        });
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(Login.this,MainActivity.class);
                startActivity(loginIntent);
                finish();

            }
        });

    }
}