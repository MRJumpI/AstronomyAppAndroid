package com.example.projectastronomyapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projectastronomyapp.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignUp extends AppCompatActivity {

    String selectedRbText;
    EditText name,email,password;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    ProgressDialog progressDialog;

    CheckBox btnPrivacy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sign_up);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        progressDialog = new ProgressDialog(SignUp.this);
        name = (EditText) findViewById(R.id.etName);
        email = (EditText) findViewById(R.id.etEmail);
        password = (EditText) findViewById(R.id.etPassword);
        btnPrivacy = (CheckBox) findViewById(R.id.btnprivacy);
        Button signup=(Button) findViewById(R.id.signbtn);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Initialize the EditText objects with the correct IDs
                String emailV = email.getText().toString();
                String nameV = name.getText().toString();
                String passwordV = password.getText().toString();

                if( nameV.isEmpty()||emailV.isEmpty()||passwordV.isEmpty()||!(btnPrivacy.isChecked()) ){
                    Dialog dialog=new Dialog(SignUp.this);
                    dialog.setContentView(R.layout.dialog_layout);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                    Button close= dialog.findViewById(R.id.cancelbtn);
                    TextView head= dialog.findViewById(R.id.errorMsg);
                    TextView msg=dialog.findViewById(R.id.detail);
                    head.setText("Error Cardinalities !");
                    msg.setText("Make Sure to Fill Compelety. Don't Miss any field.");

                    close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.cancel();
                        }
                    });
                    dialog.show();
                    return  ;
                }


                progressDialog.show();
                firebaseAuth.createUserWithEmailAndPassword(emailV, passwordV)
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                startActivity(new Intent(SignUp.this, Login.class));
                                name.setText("");
                                email.setText("");
                                password.setText("");
                                progressDialog.cancel();
                                firebaseFirestore.collection("User")
                                        .document(FirebaseAuth.getInstance().getUid()).set(new UserModel(nameV, emailV, passwordV));
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Dialog dialog=new Dialog(SignUp.this);
                                dialog.setContentView(R.layout.dialog_layout);
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                                dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                                Button close= dialog.findViewById(R.id.cancelbtn);
                                TextView head= dialog.findViewById(R.id.errorMsg);
                                TextView msg=dialog.findViewById(R.id.detail);
                                head.setText("Error FireBase !");

                                msg.setText(e.getMessage());

                                close.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog.cancel();
                                    }
                                });
                                dialog.show();
                                progressDialog.cancel();
                                return ;
                            }
                        });
            }
        });
    }

}