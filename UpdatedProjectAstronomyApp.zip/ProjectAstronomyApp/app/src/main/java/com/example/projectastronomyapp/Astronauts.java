package com.example.projectastronomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Astronauts extends AppCompatActivity {
    Button back,findmore1,findmore2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_astronauts);

        String url1="https://www.nasa.gov/astronauts";
        String url2="https://www.nasa.gov/audience/forstudents/postsecondary/features/F_Astronaut_Requirements.html";

        findmore1=(Button) findViewById(R.id.findmorebtn1);
        findmore1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Astronauts.this, "Going to NASA website.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url1));
                startActivity(i);
            }
        });

        findmore2=(Button) findViewById(R.id.findmorebtn2);
        findmore2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Astronauts.this, "Going to NASA website.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url2));
                startActivity(i);
            }
        });

        back=(Button) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(Astronauts.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });
    }
}