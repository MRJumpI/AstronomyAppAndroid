package com.example.projectastronomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class HiddenPlanet extends AppCompatActivity {
    Button back,findmore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hidden_planet);
        String url="https://www.npr.org/sections/thetwo-way/2016/01/20/463087037/hints-of-a-hidden-distant-planet-in-our-solar-system";

        findmore=(Button) findViewById(R.id.findmorebtn);
        findmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HiddenPlanet.this, "Going to NASA website.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        back=(Button) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(HiddenPlanet.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });

    }
}