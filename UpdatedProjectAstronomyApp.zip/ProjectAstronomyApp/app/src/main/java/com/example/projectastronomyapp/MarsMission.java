package com.example.projectastronomyapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.SSLHandshakeException;

public class MarsMission extends AppCompatActivity  {
//
//    //news
    private static final String API_KEY = "t4vooFxB0oii7zE0aFOe6U83mzz2Unsd-mFhbgGY92E";
    private static final String API_URL = "https://api.newscatcherapi.com/v2/search?q=MARS";
    Button  back;
    public LinearLayout disable1,disable2,disable3;
    public TextView data1,title1,write1,readdetail1,rank1,lan1,con1,sum1;
    public TextView data2,title2,write2,readdetail2,rank2,lan2,con2,sum2;
    public TextView data3,title3,write3,readdetail3,rank3,lan3,con3,sum3;
    public Button readbtn1,readbtn2,readbtn3;
    public ImageView img1,img2,img3;
    private TextView newsMarsTextView;

    private int userInputId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mars_mission);
        newsMarsTextView = findViewById(R.id.newsMarsTextView);

        //intialization
        back=(Button) findViewById(R.id.back);

        disable1=(LinearLayout) findViewById(R.id.disableLayer1);
        disable2=(LinearLayout) findViewById(R.id.disableLayer2);
        disable3=(LinearLayout) findViewById(R.id.disableLayer3);

        img1 = (ImageView) findViewById(R.id.img1);
        img2 = (ImageView) findViewById(R.id.img2);
        img3 = (ImageView) findViewById(R.id.img3);

        data1=(TextView) findViewById(R.id.date1);
        data2=(TextView) findViewById(R.id.date2);
        data3=(TextView) findViewById(R.id.date3);

        title1=(TextView) findViewById(R.id.title1);
        title2=(TextView) findViewById(R.id.title2);
        title3=(TextView) findViewById(R.id.title3);

        write1=(TextView) findViewById(R.id.writer1);
        write2=(TextView) findViewById(R.id.writer2);
        write3=(TextView) findViewById(R.id.writer3);

        readdetail1=(TextView) findViewById(R.id.detailbtn1);
        readdetail2=(TextView) findViewById(R.id.detailbtn2);
        readdetail3=(TextView) findViewById(R.id.detailbtn3);

        rank1=(TextView) findViewById(R.id.rank1);
        rank2=(TextView) findViewById(R.id.rank2);
        rank3=(TextView) findViewById(R.id.rank3);

        lan1=(TextView) findViewById(R.id.lan1);
        lan2=(TextView) findViewById(R.id.lan2);
        lan3=(TextView) findViewById(R.id.lan3);

        con1=(TextView) findViewById(R.id.con1);
        con2=(TextView) findViewById(R.id.con2);
        con3=(TextView) findViewById(R.id.con3);

        sum1=(TextView) findViewById(R.id.summary1);
        sum2=(TextView) findViewById(R.id.summary2);
        sum3=(TextView) findViewById(R.id.summary3);

        readbtn1=(Button) findViewById(R.id.readbtn1);
        readbtn2=(Button) findViewById(R.id.readbtn2);
        readbtn3=(Button) findViewById(R.id.readbtn3);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(MarsMission.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });

        readdetail1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable1.getVisibility()==View.GONE){
                    disable1.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{

                    disable1.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail1.setText(text);

            }
        });



//        news
//         Get the current system date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());

//         Build the API URL with the current date
        String apiUrl = API_URL + "&from=" + currentDate;

//         Execute the AsyncTask to fetch news
        new FetchMarsNewsTask().execute(apiUrl);



    }

    public void expand(View v){
        readdetail2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable2.getVisibility()==View.GONE){
                    disable2.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{
                    disable2.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail2.setText(text);

            }

        });
        readdetail3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable3.getVisibility()==View.GONE){
                    disable3.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{
                    disable3.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail3.setText(text);


            }
        });
    }


    private class FetchMarsNewsTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            StringBuilder response = new StringBuilder();

            try {
                URL url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-Api-Key", API_KEY);
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                } else {
                    Log.e("FetchNewsTask", "Error: " + responseCode);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            return response.toString();
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            try {

                JSONObject jsonObject = new JSONObject(result);
                JSONArray articlesArray = jsonObject.getJSONArray("articles");

                // Display the first two news articles
                StringBuilder newsText = new StringBuilder();
                for (int i = 0; i < 3 && i < articlesArray.length(); i++) {
                    JSONObject article = articlesArray.getJSONObject(i);
                    String title = article.getString("title");
                    String author = article.getString("authors");
                    String publishedDate = article.getString("published_date");
                    String summary = article.getString("summary");
                    String link = article.getString("link");
                    int rank = article.getInt("rank");
                    String language = article.getString("language");
                    String country = article.getString("country");
                    String urlImg=article.getString("media");
                    String url=article.getString("link");

                    // Set the retrieved data to the respective TextViews

                    switch (i) {
                        case 0:
                            title1.setText(title);
                            write1.setText(author);
                            data1.setText(publishedDate);
                            sum1.setText(summary);
                            rank1.setText(String.valueOf(rank));
                            lan1.setText(language);
                            con1.setText(country);
                            Glide.with(MarsMission.this).load(urlImg).into(img1);
                            readbtn1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Toast.makeText(MarsMission.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setData(Uri.parse(url));
                                    startActivity(i);
                                }
                            });

                            break;
                        case 1:
                            title2.setText(title);
                            write2.setText(author);
                            data2.setText(publishedDate);
                            sum2.setText(summary);
                            rank2.setText(String.valueOf(rank));
                            lan2.setText(language);
                            con2.setText(country);

                            Glide.with(MarsMission.this).load(urlImg).into(img2);
                            readbtn2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Toast.makeText(MarsMission.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setData(Uri.parse(url));
                                    startActivity(i);
                                }
                            });

                            break;
                        case 2:
                            title3.setText(title);
                            write3.setText(author);
                            data3.setText(publishedDate);
                            sum3.setText(summary);
                            rank3.setText(String.valueOf(rank));
                            lan3.setText(language);
                            con3.setText(country);

                            Glide.with(MarsMission.this).load(urlImg).into(img3);
                            readbtn3.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Toast.makeText(MarsMission.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setData(Uri.parse(url));
                                    startActivity(i);
                                }
                            });

                            break;
                    }
                }

                newsMarsTextView.setText(newsText.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}