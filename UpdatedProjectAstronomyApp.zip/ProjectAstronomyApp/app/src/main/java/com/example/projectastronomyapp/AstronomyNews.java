package com.example.projectastronomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
//API KEY- sy-kyaQK-_liyhrNH0U03wO7TkOgKbcPoIUPrQLnoGw
public class AstronomyNews extends AppCompatActivity {
    public TextView newsTextView,newsTextView2;
    Button  back;
    public ImageView img1,img2,img3,img4,img5;
    public LinearLayout disable1,disable2,disable3,disable4,disable5;
    public TextView data1,title1,write1,readdetail1,rank1,lan1,con1,sum1;
    public TextView data2,title2,write2,readdetail2,rank2,lan2,con2,sum2;
    public TextView data3,title3,write3,readdetail3,rank3,lan3,con3,sum3;
    public TextView data4,title4,write4,readdetail4,rank4,lan4,con4,sum4;
    public TextView data5,title5,write5,readdetail5,rank5,lan5,con5,sum5;
    int no;
    public Button readbtn1,readbtn2,readbtn3,readbtn4,readbtn5;
    boolean nasa,asatronmy;
    private static final String API_URL1 = "https://api.newscatcherapi.com/v2/search?q=Nasa";
    private static final String API_URL2 = "https://api.newscatcherapi.com/v2/search?q=Astronomy";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_astronomy_news);
        no=0;
        back=(Button) findViewById(R.id.back);

        //intialization
        disable1=(LinearLayout) findViewById(R.id.disableLayer1);
        disable2=(LinearLayout) findViewById(R.id.disableLayer2);
        disable3=(LinearLayout) findViewById(R.id.disableLayer3);
        disable4=(LinearLayout) findViewById(R.id.disableLayer4);
        disable5=(LinearLayout) findViewById(R.id.disableLayer5);

        img1 = (ImageView) findViewById(R.id.img1);
        img2 = (ImageView) findViewById(R.id.img2);
        img3 = (ImageView) findViewById(R.id.img3);
        img4 = (ImageView) findViewById(R.id.img4);
        img5 = (ImageView) findViewById(R.id.img5);

        data1=(TextView) findViewById(R.id.date1);
        data2=(TextView) findViewById(R.id.date2);
        data3=(TextView) findViewById(R.id.date3);
        data4=(TextView) findViewById(R.id.date4);
        data5=(TextView) findViewById(R.id.date5);

        title1=(TextView) findViewById(R.id.title1);
        title2=(TextView) findViewById(R.id.title2);
        title3=(TextView) findViewById(R.id.title3);
        title4=(TextView) findViewById(R.id.title4);
        title5=(TextView) findViewById(R.id.title5);

        write1=(TextView) findViewById(R.id.writer1);
        write2=(TextView) findViewById(R.id.writer2);
        write3=(TextView) findViewById(R.id.writer3);
        write4=(TextView) findViewById(R.id.writer4);
        write5=(TextView) findViewById(R.id.writer5);

        readdetail1=(TextView) findViewById(R.id.detailbtn1);
        readdetail2=(TextView) findViewById(R.id.detailbtn2);
        readdetail3=(TextView) findViewById(R.id.detailbtn3);
        readdetail4=(TextView) findViewById(R.id.detailbtn4);
        readdetail5=(TextView) findViewById(R.id.detailbtn1);

        rank1=(TextView) findViewById(R.id.rank1);
        rank2=(TextView) findViewById(R.id.rank2);
        rank3=(TextView) findViewById(R.id.rank3);
        rank4=(TextView) findViewById(R.id.rank4);
        rank5=(TextView) findViewById(R.id.rank5);

        lan1=(TextView) findViewById(R.id.lan1);
        lan2=(TextView) findViewById(R.id.lan2);
        lan3=(TextView) findViewById(R.id.lan3);
        lan4=(TextView) findViewById(R.id.lan4);
        lan5=(TextView) findViewById(R.id.lan5);

        con1=(TextView) findViewById(R.id.con1);
        con2=(TextView) findViewById(R.id.con2);
        con3=(TextView) findViewById(R.id.con3);
        con4=(TextView) findViewById(R.id.con4);
        con5=(TextView) findViewById(R.id.con5);

        sum1=(TextView) findViewById(R.id.summary1);
        sum2=(TextView) findViewById(R.id.summary2);
        sum3=(TextView) findViewById(R.id.summary3);
        sum4=(TextView) findViewById(R.id.summary4);
        sum5=(TextView) findViewById(R.id.summary5);

        readbtn1=(Button) findViewById(R.id.readbtn1);
        readbtn2=(Button) findViewById(R.id.readbtn2);
        readbtn3=(Button) findViewById(R.id.readbtn3);
        readbtn4=(Button) findViewById(R.id.readbtn4);
        readbtn5=(Button) findViewById(R.id.readbtn5);

        newsTextView2 = findViewById(R.id.newsTextView2);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(AstronomyNews.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });

        readdetail1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable1.getVisibility()==View.GONE){
                    disable1.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{

                    disable1.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail1.setText(text);

            }
        });



        // Fetch news data

        loadNews1();
        loadNews2();
    }

    public void expand(View v){
        readdetail2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable2.getVisibility()==View.GONE){
                    disable2.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{
                    disable2.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail2.setText(text);

            }

        });
        readdetail3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable3.getVisibility()==View.GONE){
                    disable3.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{
                    disable3.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail3.setText(text);


            }
        });
        readdetail4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable4.getVisibility()==View.GONE){
                    disable4.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{
                    disable4.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail4.setText(text);


            }
        });
        readdetail5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text;
                String t1="Show Less";
                String t2="Read Details";

                if(disable5.getVisibility()==View.GONE){
                    disable5.setVisibility(View.VISIBLE);
                    text= t1;
                }
                else{
                    disable5.setVisibility(View.GONE);
                    text= t2;
                }
                readdetail5.setText(text);


            }
        });

    }
    private void loadNews1() {
        nasa=true;
        asatronmy=false;
        String requestUrl = API_URL1 ;
        new FetchNewsTask().execute(requestUrl);
        no=3;
        Toast.makeText(this, "Working on News", Toast.LENGTH_SHORT).show();

    }

    private void loadNews2() {
        nasa=false;
        asatronmy=true;
        String requestUrl = API_URL2;
        new FetchAstronmyNewsTask().execute(requestUrl);
        no=2;
        Toast.makeText(this, "Working", Toast.LENGTH_SHORT).show();

    }
    private class FetchNewsTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-Api-Key", "t4vooFxB0oii7zE0aFOe6U83mzz2Unsd-mFhbgGY92E");
                InputStream inputStream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonResponse = new JSONObject(result);
                    if (jsonResponse.length() > 0) {
                        JSONArray articles = jsonResponse.getJSONArray("articles");

                        String newsText = "";
                        for (int i = 0; i < 3 && i < articles.length(); i++) {
                            JSONObject article = articles.getJSONObject(i);
                            String title = article.getString("title");
                            String author = article.getString("authors");
                            String publishedDate = article.getString("published_date");
                            String summary = article.getString("summary");
                            String link = article.getString("link");
                            int rank = article.getInt("rank");
                            String language = article.getString("language");
                            String country = article.getString("country");
                            String urlImg=article.getString("media");
                            String url=article.getString("link");

                            // Set the retrieved data to the respective TextViews

                            switch (i) {
                                case 0:
                                    title1.setText(title);
                                    write1.setText(author);
                                    data1.setText(publishedDate);
                                    sum1.setText(summary);
                                    rank1.setText(String.valueOf(rank));
                                    lan1.setText(language);
                                    con1.setText(country);
                                    Glide.with(AstronomyNews.this).load(urlImg).into(img1);
                                    readbtn1.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Toast.makeText(AstronomyNews.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                            Intent i = new Intent(Intent.ACTION_VIEW);
                                            i.setData(Uri.parse(url));
                                            startActivity(i);
                                        }
                                    });

                                    break;
                                case 1:
                                    title2.setText(title);
                                    write2.setText(author);
                                    data2.setText(publishedDate);
                                    sum2.setText(summary);
                                    rank2.setText(String.valueOf(rank));
                                    lan2.setText(language);
                                    con2.setText(country);

                                    Glide.with(AstronomyNews.this).load(urlImg).into(img2);
                                    readbtn2.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Toast.makeText(AstronomyNews.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                            Intent i = new Intent(Intent.ACTION_VIEW);
                                            i.setData(Uri.parse(url));
                                            startActivity(i);
                                        }
                                    });

                                    break;
                                case 2:
                                    title3.setText(title);
                                    write3.setText(author);
                                    data3.setText(publishedDate);
                                    sum3.setText(summary);
                                    rank3.setText(String.valueOf(rank));
                                    lan3.setText(language);
                                    con3.setText(country);

                                    Glide.with(AstronomyNews.this).load(urlImg).into(img3);
                                    readbtn3.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Toast.makeText(AstronomyNews.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                            Intent i = new Intent(Intent.ACTION_VIEW);
                                            i.setData(Uri.parse(url));
                                            startActivity(i);
                                        }
                                    });

                                    break;
                            }
                        }

                    } else {
                        Toast.makeText(AstronomyNews.this, "API Error: Status is not OK", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(AstronomyNews.this, "JSON Parsing Error", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(AstronomyNews.this, "Failed to fetch news data!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class FetchAstronmyNewsTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-Api-Key", "t4vooFxB0oii7zE0aFOe6U83mzz2Unsd-mFhbgGY92E");
                InputStream inputStream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonResponse = new JSONObject(result);
                    if (jsonResponse.length() > 0) {
                        JSONArray articles = jsonResponse.getJSONArray("articles");

                        String newsText = "";
                        for (int i = 0; i < 2 && i < articles.length(); i++) {
                            JSONObject article = articles.getJSONObject(i);
                            String title = article.getString("title");
                            String author = article.getString("authors");
                            String publishedDate = article.getString("published_date");
                            String summary = article.getString("summary");
                            String link = article.getString("link");
                            int rank = article.getInt("rank");
                            String language = article.getString("language");
                            String country = article.getString("country");
                            String urlImg=article.getString("media");
                            String url=article.getString("link");
                            // Set the retrieved data to the respective TextViews

                            switch (i) {
                                case 0:
                                    title4.setText(title);
                                    write4.setText(author);
                                    data4.setText(publishedDate);
                                    sum4.setText(summary);
                                    rank4.setText(String.valueOf(rank));
                                    lan4.setText(language);
                                    con4.setText(country);
                                    Glide.with(AstronomyNews.this).load(urlImg).into(img4);
                                    readbtn4.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Toast.makeText(AstronomyNews.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                            Intent i = new Intent(Intent.ACTION_VIEW);
                                            i.setData(Uri.parse(url));
                                            startActivity(i);
                                        }
                                    });
                                    break;
                                case 1:
                                    title5.setText(title);
                                    write5.setText(author);
                                    data5.setText(publishedDate);
                                    sum5.setText(summary);
                                    rank5.setText(String.valueOf(rank));
                                    lan5.setText(language);
                                    con5.setText(country);

                                    Glide.with(AstronomyNews.this).load(urlImg).into(img5);
                                    readbtn5.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Toast.makeText(AstronomyNews.this, "Going to  website.", Toast.LENGTH_SHORT).show();
                                            Intent i = new Intent(Intent.ACTION_VIEW);
                                            i.setData(Uri.parse(url));
                                            startActivity(i);
                                        }
                                    });

                                    break;
                            }
                        }

                    } else {
                        Toast.makeText(AstronomyNews.this, "API Error: Status is not OK", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(AstronomyNews.this, "JSON Parsing Error", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(AstronomyNews.this, "Failed to fetch news data!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}