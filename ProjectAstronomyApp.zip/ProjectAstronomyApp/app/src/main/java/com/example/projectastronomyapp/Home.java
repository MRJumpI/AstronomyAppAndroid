package com.example.projectastronomyapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.animation.LayoutTransition;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.VideoView;
import android.widget.ViewFlipper;

import com.bumptech.glide.Glide;
import com.example.projectastronomyapp.utils.NetworkUtils;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


//hbTwMae2DZhPyF0917cTNCcMLXQDzB7BQOkLFhXe -APIKEY for pic of the day
public class Home extends AppCompatActivity {
    BottomNavigationView bnView;
    RelativeLayout homelayout;
    String title_ofpicofday;
    LinearLayout linear,lL1,lL2;
    LinearLayout videoofDay,btnTaskShow;
    Button slide1btn,slide2btn,slide3btn,slide4btn,slide5btn,slide6btn,searchPage,newsPage,marsmission;
    TextView detailbtn;
    Button aboutPage;
    Animation fadein,fadeout;
    ImageView picofDay;
    String date_ofpicofday;
    String explenation_ofpicofday;
    String url_ofpicofday;
    Button playgame;
    TextView title_pic,date_pic,explenation_pic;
    String receivedValue;
    Switch switchAutoStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //Initialization
        ViewFlipper viewFlipper = findViewById(R.id.sliderBar);
        Button nextButton = findViewById(R.id.nextButton);

        playgame =(Button) findViewById(R.id.playgameQuiz);
        marsmission=(Button) findViewById(R.id.marsmission);
        newsPage=(Button) findViewById(R.id.newsPage);
        searchPage = (Button) findViewById(R.id.searchPage);
        slide1btn=(Button) findViewById(R.id.slide1btn);
        slide2btn=(Button) findViewById(R.id.slide2btn);
        slide3btn=(Button) findViewById(R.id.slide3btn);
        slide4btn=(Button) findViewById(R.id.slide4btn);
        slide5btn=(Button) findViewById(R.id.slide5btn);
        slide6btn=(Button) findViewById(R.id.slide6btn);

        picofDay=(ImageView) findViewById(R.id.picofDay);
        title_pic=(TextView) findViewById(R.id.titlepic);
        date_pic=(TextView) findViewById(R.id.datepic);
        explenation_pic=(TextView) findViewById(R.id.explenationpic);
        videoofDay=(LinearLayout) findViewById(R.id.videoofDay);
        btnTaskShow=(LinearLayout) findViewById(R.id.btnTaskShow);
        switchAutoStart = findViewById(R.id.switchAutoStart);
        homelayout = findViewById(R.id.homeScreen);

        Intent intent = getIntent();
        receivedValue = intent.getStringExtra("email");

        final int[] turnCheck = new int[1];
        turnCheck[0] =0;
        //Api Pic of Day
        try {
            getData();
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }


        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewFlipper.showNext();
            }
        });


        //Bottom Navigation
        bnView=(BottomNavigationView) findViewById(R.id.btNvView);
        bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int check=0;
                int id =item.getItemId();
                if(id==R.id.home){
                    Toast.makeText(Home.this, "Home", Toast.LENGTH_SHORT).show();
                    homelayout.setVisibility(View.VISIBLE);
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    List<Fragment> fragmentList = fragmentManager.getFragments();
                    turnCheck[0] = 0;
                    if (fragmentList != null) {
                        for (Fragment fragment : fragmentList) {
                            if (fragment != null) {
                                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                                fragmentTransaction.detach(fragment); // Stop the fragment
                                fragmentTransaction.commit();
                            }
                        }
                    }
                }else if(id==R.id.about){
                    Toast.makeText(Home.this, "About", Toast.LENGTH_SHORT).show();
                    homelayout.setVisibility(View.GONE);
                    if(turnCheck[0] ==0){
                           turnCheck[0]++;
                    }
                    onload(new AboutUsFragment(),turnCheck[0]);

                    } else  {


                    homelayout.setVisibility(View.GONE);
                    homelayout.setVisibility(View.GONE);
                    if(turnCheck[0] ==0){
                        turnCheck[0]++;
                    }
                    onload(new AccountFragment(),turnCheck[0]);
                    //Create Dialogue Box for User Info and logout Btn
                }

                return true;

            }
        });

        //buttonS MEthod


        switchAutoStart.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    btnTaskShow.setVisibility(View.GONE);
                    viewFlipper.setAutoStart(true);
                    viewFlipper.startFlipping();
                } else {

                    btnTaskShow.setVisibility(View.VISIBLE);
                    viewFlipper.stopFlipping();
                    viewFlipper.setAutoStart(false);
                }
            }
        });
        playgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home.this,PlayGame.class);
                startActivity(intent);
                finish();
            }
        });
        marsmission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,MarsMission.class);
                startActivity(intent);
                finish();

            }
        });
        newsPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,AstronomyNews.class);
                startActivity(intent);
                finish();

            }
        });

        searchPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,SearchAStar.class);
                startActivity(intent);
                finish();

            }
        });
        slide1btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Home.this, "Solar System", Toast.LENGTH_SHORT).show();

                Intent loginIntent = new Intent(Home.this,SolarSystem.class);
                startActivity(loginIntent);
                finish();

            }
        });

        slide2btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Home.this, "Glaxy", Toast.LENGTH_SHORT).show();

                Intent loginIntent = new Intent(Home.this,Glaxy.class);
                startActivity(loginIntent);
                finish();

            }
        });


        slide3btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Home.this, "Black hole", Toast.LENGTH_SHORT).show();

                Intent loginIntent = new Intent(Home.this,BlackHole.class);
                startActivity(loginIntent);
                finish();

            }
        });


        slide4btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Home.this, "Pillar of Creation", Toast.LENGTH_SHORT).show();

                Intent loginIntent = new Intent(Home.this,PillarsOfCreation.class);
                startActivity(loginIntent);
                finish();

            }
        });

        slide5btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Home.this, "Astronauts", Toast.LENGTH_SHORT).show();

                Intent loginIntent = new Intent(Home.this,Astronauts.class);
                startActivity(loginIntent);
                finish();

            }
        });


        slide6btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Home.this, "Hidden Planet", Toast.LENGTH_SHORT).show();

                Intent loginIntent = new Intent(Home.this,HiddenPlanet.class);
                startActivity(loginIntent);
                finish();

            }
        });
    }

    public void onload(Fragment fragment,int turn){
        Bundle bundle = new Bundle();
        bundle.putString("email", receivedValue);
        fragment.setArguments(bundle);
        FragmentManager fragmentmanager= getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentmanager.beginTransaction();
        if(turn == 0)
            fragmentTransaction.add(R.id.container,fragment);
        else
            fragmentTransaction.replace(R.id.container,fragment);

        fragmentTransaction.commit();
    }
    public void expand(View v){
        detailbtn=findViewById(R.id.detailbtn);
        fadein = AnimationUtils.loadAnimation(Home.this,R.anim.fade_in);
        fadeout = AnimationUtils.loadAnimation(Home.this,R.anim.fade_out);
        String text;
        lL1= findViewById(R.id.lL1);
        lL2= findViewById(R.id.lL2);

        linear= findViewById(R.id.LinearLayoutCard);

        String t1="Show Less";
        String t2="Read Details";

        if(lL1.getVisibility()==View.GONE){
            lL1.setVisibility(View.VISIBLE);
            lL2.setVisibility(View.VISIBLE);

             text= t1;
        }
        else{

            lL1.setVisibility(View.GONE);
            lL2.setVisibility(View.GONE);

            text= t2;
        }


        detailbtn.setText(text);

    }
    public void getData() throws MalformedURLException {
        Uri uri=Uri.parse("https://api.nasa.gov/planetary/apod?api_key=hbTwMae2DZhPyF0917cTNCcMLXQDzB7BQOkLFhXe").buildUpon().build();
        URL m_url=new URL(uri.toString());
        new DOTask().execute(m_url);
    }
    class DOTask extends AsyncTask<URL, Void, String> {

        @Override
        protected String doInBackground(URL... urls) {
            URL url = urls [0];
            String data=null;
            try {
                data = NetworkUtils.makeHTTPRequest(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return data;
        }

        public void loadVideo(String vid){
            YouTubePlayerView youTubePlayerView = findViewById(R.id.youtube_player_view);
            getLifecycle().addObserver(youTubePlayerView);

            youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
                @Override
                public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                    String videoId = vid;
                    youTubePlayer.loadVideo(videoId, 0);
                }
            });
        }

        public String extractVideoId(String youtubeLink) {
            String videoId = null;
            String pattern = "(?:embed\\/|watch\\?v=|youtu.be\\/|\\/v\\/|\\/e\\/|\\/user\\/\\w+\\/|vi\\/|\\/v\\/|\\/e\\/|\\/user\\/\\w+\\/|embed\\/|watch\\?v=|youtu.be\\/|\\/v\\/|\\/e\\/|\\/user\\/\\w+\\/|vi\\/|\\?v=|&v=|\\/videos\\/|embed\\/|youtu.be\\/|\\/v\\/|\\/e\\/|\\/user\\/\\w+\\/|vi\\/|\\/v\\/|\\/e\\/|\\/user\\/\\w+\\/|embed\\?video_id=)([^#\\&\\?\\n]+)";

            Pattern compiledPattern = Pattern.compile(pattern);
            Matcher matcher = compiledPattern.matcher(youtubeLink);
            if (matcher.find()) {
                videoId = matcher.group(1);
            }
            return videoId;
        }

        @Override
        public void  onPostExecute(String s){
            parseJson(s);
        }

        public  void parseJson(String data){
            JSONObject jsonObject=null;
            try {
                jsonObject=new JSONObject(data);

            }
            catch (Exception e){
                e.printStackTrace();
            }

            try {
                title_ofpicofday=jsonObject.getString("title");
                date_ofpicofday=jsonObject.getString("date");
                explenation_ofpicofday=jsonObject.getString("explanation");
                url_ofpicofday=jsonObject.getString("url");
                String media=jsonObject.getString("media_type");
                title_pic.setText(title_ofpicofday);
                date_pic.setText(date_ofpicofday);
                explenation_pic.setText(explenation_ofpicofday);
                //load img
                if(media.equalsIgnoreCase("video")){
                    videoofDay.setVisibility(View.VISIBLE);
                    //Creating MediaController
                    String youtubeLink =url_ofpicofday;
                    String vid = extractVideoId(youtubeLink);
                    loadVideo(vid);

                }
                else {
                    Glide.with(Home.this).load(url_ofpicofday).into(picofDay);

                    picofDay.setVisibility(View.VISIBLE);
                }
            } catch (JSONException e) {
//                throw new RuntimeException(e);
                Dialog dialog=new Dialog(Home.this);
                dialog.setContentView(R.layout.apidialog_layout);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                Button close= dialog.findViewById(R.id.cancelbtn);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
                dialog.show();
            }
            }
        }
    }

