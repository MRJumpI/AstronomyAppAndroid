package com.example.projectastronomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PillarsOfCreation extends AppCompatActivity {
    Button back,findmore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pillars_of_creation);
        String url="https://www.sciencefriday.com/segments/universal-harmonies-space-sonification/";

        findmore=(Button) findViewById(R.id.findmorebtn);
        findmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PillarsOfCreation.this, "Going to NASA website.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        back=(Button) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(PillarsOfCreation.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });

    }
}