package com.example.projectastronomyapp;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class Q5Fragment extends Fragment {
    private RadioButton radioButton1, radioButton2, radioButton3;
    private Button submitButton;

    public Q5Fragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_q5, container, false);

        radioButton1 = view.findViewById(R.id.radioButton1);
        radioButton2 = view.findViewById(R.id.radioButton2);
        radioButton3 = view.findViewById(R.id.radioButton3);
        submitButton = view.findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isCorrect = radioButton2.isChecked();
                if(!isCorrect){

                    Dialog dialog=new Dialog(requireContext());
                    dialog.setContentView(R.layout.apidialog_layout);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                    TextView txt=dialog.findViewById(R.id.txt2);
                    txt.setText("Wrong Answer!");
                    Button close= dialog.findViewById(R.id.cancelbtn);
                    close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.cancel();
                        }
                    });
                    dialog.show();
                }
                else{
                    Dialog dialog=new Dialog(requireContext());
                    dialog.setContentView(R.layout.apidialog_layout);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                    TextView txt1=dialog.findViewById(R.id.txt1);
                    txt1.setText("Welldone Commandor...🤖🤖");
                    TextView txt=dialog.findViewById(R.id.txt2);

                    txt.setTextColor(Color.GREEN);
                    txt.setText("Congratulation! You have a good knowledge about Astronomy. We are impressed ❤️✨");
                    Button close= dialog.findViewById(R.id.cancelbtn);
                    close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.cancel();
                        }
                    });
                    dialog.show();
                    FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();

                    // Clear the back stack
                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);

                }
            }
        });


        return view;
    }
}