package com.example.projectastronomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BlackHole extends AppCompatActivity {
    Button back,findmore1,findmore2;
    TextView detailbtn;
    LinearLayout linear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_black_hole);
        String url1="https://www.nasa.gov/vision/universe/starsgalaxies/black_hole_description.html";
        String url2="https://science.nasa.gov/astrophysics/focus-areas/black-holes";

        findmore1=(Button) findViewById(R.id.findmorebtn1);
        findmore1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(BlackHole.this, "Going to NASA website.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url1));
                startActivity(i);
            }
        });
        findmore2=(Button) findViewById(R.id.findmorebtn2);
        findmore2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(BlackHole.this, "Going to NASA website.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url1));
                startActivity(i);
            }
        });


        back=(Button) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(BlackHole.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });

    }

    public void expand(View v){
        detailbtn=findViewById(R.id.detailbtn);
        String text;

        linear= findViewById(R.id.disableLayer);

        String t1="Show Less";
        String t2="Read Details";

        if(linear.getVisibility()==View.GONE){
            linear.setVisibility(View.VISIBLE);
            text= t1;
        }
        else{
            linear.setVisibility(View.GONE);
            text= t2;
        }


        detailbtn.setText(text);

    }


}
