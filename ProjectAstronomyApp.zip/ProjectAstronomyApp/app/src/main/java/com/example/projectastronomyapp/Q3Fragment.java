package com.example.projectastronomyapp;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class Q3Fragment extends Fragment {
    private RadioButton radioButton1, radioButton2, radioButton3;
    private Button submitButton;

    public Q3Fragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_q3, container, false);
        radioButton1 = view.findViewById(R.id.radioButton1);
        radioButton2 = view.findViewById(R.id.radioButton2);
        radioButton3 = view.findViewById(R.id.radioButton3);
        submitButton = view.findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isCorrect = radioButton3.isChecked();
                if(!isCorrect){

                    Dialog dialog=new Dialog(requireContext());
                    dialog.setContentView(R.layout.apidialog_layout);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                    TextView txt=dialog.findViewById(R.id.txt2);
                    txt.setText("Wrong Answer!");
                    Button close= dialog.findViewById(R.id.cancelbtn);
                    close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.cancel();
                        }
                    });
                    dialog.show();
                }
                else{
                    Q4Fragment newFragment = new Q4Fragment();
                    FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                    // Clear the back stack
                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);

                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.container, newFragment);
                    fragmentTransaction.addToBackStack(null); // Add the transaction to the back stack
                    fragmentTransaction.commit();
                }
            }
        });



        return view;
    }
}