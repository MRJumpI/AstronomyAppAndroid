package com.example.projectastronomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SolarSystem extends AppCompatActivity {
    Button back,findmore;
    TextView detailbtn;
    LinearLayout linear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solar_system);

        String url="https://solarsystem.nasa.gov/solar-system/our-solar-system/overview/";

        findmore=(Button) findViewById(R.id.findmorebtn);
        findmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SolarSystem.this, "Going to NASA website.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        back=(Button) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(SolarSystem.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });

    }

    public void expand(View v){
        detailbtn=findViewById(R.id.detailbtn);
        String text;

        linear= findViewById(R.id.disableLayer);

        String t1="Show Less";
        String t2="Read Details";

        if(linear.getVisibility()==View.GONE){
            linear.setVisibility(View.VISIBLE);
            text= t1;
        }
        else{
            linear.setVisibility(View.GONE);
            text= t2;
        }


        detailbtn.setText(text);

    }


}