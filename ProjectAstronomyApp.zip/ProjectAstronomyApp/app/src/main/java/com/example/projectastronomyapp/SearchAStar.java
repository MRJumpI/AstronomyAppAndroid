package com.example.projectastronomyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.projectastronomyapp.utils.NetworkUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class SearchAStar extends AppCompatActivity {
    Button search;
    Button  back;
    LinearLayout ll;
    EditText nameStar;
    TextView resultTextViewname,resultTextconstellation,resultTextdeclination,resultTextright_ascension,resultTextapparent_magnitude,resultTextabsolute_magnitude,resultTextdistance_light_year,resultTextspectral_class;
    private static final String API_URL = "https://api.api-ninjas.com/v1/stars";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_astar);
        //initalization
        ll=(LinearLayout) findViewById(R.id.LinearLayoutCard);
        resultTextViewname=(TextView) findViewById(R.id.resultTextname);
        resultTextabsolute_magnitude=(TextView) findViewById(R.id.resultTextabsolute_magnitude);
        resultTextapparent_magnitude=(TextView) findViewById(R.id.resultTextapparent_magnitude);
        resultTextconstellation=(TextView) findViewById(R.id.resultTextconstellation);
        resultTextright_ascension=(TextView) findViewById(R.id.resultTextright_ascension);
        resultTextdistance_light_year=(TextView) findViewById(R.id.resultTextdistance_light_year);
        resultTextspectral_class=(TextView) findViewById(R.id.resultTextspectral_class);
        resultTextdeclination=(TextView) findViewById(R.id.resultTextdeclination);
        search=(Button) findViewById(R.id.search);
        nameStar=(EditText) findViewById(R.id.get_name);
        back=(Button) findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(SearchAStar.this,Home.class);
                startActivity(loginIntent);
                finish();

            }
        });


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameStar.getText().toString();
                loadStars(name);
            }
        });

    }
    private void loadStars(String name) {
        String requestUrl = API_URL + "?name=" + name;

        new LoadStarsTask().execute(requestUrl);
        Toast.makeText(this, "Working", Toast.LENGTH_SHORT).show();
        ll.setVisibility(View.VISIBLE);

    }

    private class LoadStarsTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-Api-Key", "ybSwJ3PZFJmqYvQzQLx5+w==eOLZdENipnBZAG1d");
                InputStream inputStream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray starsArray = new JSONArray(result);
                    if (starsArray.length() > 0) {
                        JSONObject star = starsArray.getJSONObject(0);
                        String starName = star.getString("name");
                        String starcon=star.getString("constellation");
                        String r_as=star.getString("right_ascension");
                        String declination=star.getString("declination");
                        String ap_mag=star.getString("apparent_magnitude");
                        String ab_mag=star.getString("absolute_magnitude");
                        String dis=star.getString("distance_light_year");
                        String spec=star.getString("spectral_class");

                        resultTextapparent_magnitude.setText(ap_mag);
                        resultTextdeclination.setText(declination);
                        resultTextright_ascension.setText(r_as);
                        resultTextspectral_class.setText(spec);
                        resultTextabsolute_magnitude.setText(ab_mag);
                        resultTextdistance_light_year.setText(dis);
                        resultTextconstellation.setText(starcon);
                        resultTextViewname.setText(starName);
                    } else {
                        resultTextViewname.setText("No stars found.");
                        resultTextapparent_magnitude.setText("");
                        resultTextdeclination.setText("");
                        resultTextright_ascension.setText("");
                        resultTextspectral_class.setText("");
                        resultTextabsolute_magnitude.setText("");
                        resultTextdistance_light_year.setText("");
                        resultTextconstellation.setText("");

                        Dialog dialog=new Dialog(SearchAStar.this);
                        dialog.setContentView(R.layout.dialog_layout);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                        Button close= dialog.findViewById(R.id.cancelbtn);
                        close.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.cancel();
                            }
                        });
                        dialog.show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                resultTextViewname.setText("Failed to load stars.");
            }
        }
    }
}