package com.example.projectastronomyapp;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class AccountFragment extends Fragment {
    TextView name,email,password;
    public AccountFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view=inflater.inflate(R.layout.fragment_account, container, false);
        // Retrieve the passed value from the activity
        String receivedValue = getArguments().getString("email"); // Replace "KEY_NAME" with the same key used in the activity

        name=view.findViewById(R.id.name);
        email=view.findViewById(R.id.email);
        password=view.findViewById(R.id.password);

        loadData(receivedValue);

        Button watch = view.findViewById(R.id.logout);
        watch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent = new Intent(requireActivity(),MainActivity.class);
                startActivity(loginIntent);
                requireActivity().finish();

            }
        });
       return view;
    }

    private void loadData(String emailV) {
        FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();


        firebaseFirestore.collection("User")
                .whereEqualTo("email", emailV)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                        // Retrieve the data associated with the email
                        String vname = documentSnapshot.getString("name");
                        String vemail = documentSnapshot.getString("email");
                        String vpassword = documentSnapshot.getString("password");

                        // Perform desired actions with the retrieved data
                        name.setText(vname);
                        email.setText(vemail);
                        password.setText(vpassword);
                    }
                })
                .addOnFailureListener(e -> {
                    // Handle any errors that occurred while retrieving data
                    Dialog dialog=new Dialog(getContext());
                    dialog.setContentView(R.layout.dialog_layout);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    dialog.getWindow().setWindowAnimations(R.style.AnimationForDialog);
                    Button close= dialog.findViewById(R.id.cancelbtn);
                    TextView head= dialog.findViewById(R.id.errorMsg);
                    TextView msg=dialog.findViewById(R.id.detail);
                    head.setText("Error FireBase !");
                    msg.setText("Error Recieving Data from Fire base.");

                });
    }
}